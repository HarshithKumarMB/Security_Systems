# ASR-Automatic-speech-recognition
Language and gender detection
